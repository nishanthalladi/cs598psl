To run the web app:

1. open up the server.R file
2. click "Run App"
3. Fix any dependency issues by installing libraries you don't have, and run again

To run proj4-html-file.Rmd, which was used to generate S matrix and do testing:

1. open the file
2. Run all cells (this takes 20+ minutes to generate the S matrix and save it to csv)